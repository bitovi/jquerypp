/*!
* jQuery++ - 1.0.1 (2013-02-07)
* http://jquerypp.com
* Copyright (c) 2013 Bitovi
* Licensed MIT
*/
(function ($) {
	return $;
})(jQuery);