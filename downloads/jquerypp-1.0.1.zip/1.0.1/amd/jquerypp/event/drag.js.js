/*!
* jQuery++ - 1.0.1 (2013-02-06)
* http://jquerypp.com
* Copyright (c) 2013 Bitovi
* Licensed MIT
*/
define(['jquery', 'jquerypp/event/drag/core', 'jquerypp/event/drag/step', 'jquerypp/event/drag/limit', 'jquerypp/event/drag/scroll'], function ($) {
	return $;
});