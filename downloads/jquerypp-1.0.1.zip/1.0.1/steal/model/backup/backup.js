//allows you to backup and restore a model instance
steal('can/observe/backup','can/model');