steal('./object/object_test','./observe/observe_test','./string/string_test', './vector/vector_test.js')
