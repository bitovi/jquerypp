steal('can/util', 'jquery', 'can/observe', function(can) {
 $.Observe = can.Observe;
	return can;
});
