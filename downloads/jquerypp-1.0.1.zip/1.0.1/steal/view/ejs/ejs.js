/*jslint evil: true */
steal('jquery', 'can/util', 'jquery/view', 'can/view/ejs', function($, can){
	$.EJS = can.EJS;
});