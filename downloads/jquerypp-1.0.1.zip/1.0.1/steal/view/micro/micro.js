steal('jquery', 'jquery/view', 'can/view/micro', function($) {
	return $;
});
