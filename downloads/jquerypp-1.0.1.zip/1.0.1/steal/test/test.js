(function(){
steal(
//	'jquery/dom/animate/animate_test.js'
//	, 'jquery/event/fastfix/fastfix_test.js'
	'jquery/dom/compare/compare_test.js'
	, 'jquery/dom/dimensions/dimensions_test.js'
	, 'jquery/dom/form_params/form_params_test.js'
	, 'jquery/dom/styles/styles_test.js'
	, 'jquery/event/default/default_test.js'
	, 'jquery/event/default/default_pause_test.js'
	, 'jquery/event/destroyed/destroyed_test.js'
	, 'jquery/event/drag/drag_test.js'
	,'jquery/event/drop/drop_test.js'
	, 'jquery/event/hover/hover_test.js'
	, 'jquery/event/key/key_test.js'
	, 'jquery/event/pause/pause_test.js'
	, 'jquery/event/reverse/reverse_test.js'
	, 'jquery/event/resize/resize_test.js'
	, 'jquery/event/swipe/swipe_test.js'
	, 'jquery/lang/lang_test.js'
	, './qunit/jmvc.js'
);
})();
