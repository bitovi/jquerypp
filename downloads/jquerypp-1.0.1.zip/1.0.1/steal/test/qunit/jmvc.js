// Tests for the JavaScriptMVC compatibility layer. Will be removed eventually
steal('funcunit/qunit', 'jquery/controller/view/test/qunit'
	, 'jquery/class/class_test.js'
	, 'jquery/model/test/qunit'
	, 'jquery/controller/controller_test.js'
	, 'jquery/view/test/qunit'
	, 'jquery/dom/route/route_test.js'
	, './integration.js');