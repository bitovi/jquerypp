steal('jquery', 'jquery/event/drag/core', 'jquery/event/drag/step', 'jquery/event/drag/limit',
	'jquery/event/drag/scroll', function( $ ) {
		return $;
});