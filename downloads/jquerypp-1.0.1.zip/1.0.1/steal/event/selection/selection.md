@page jQuery.event.selection
@parent jquerypp
@hide
