steal('funcunit/qunit','./route',function(){

module("route");

test("route testing works", function(){
	ok(true,"an assert is run");
});


});