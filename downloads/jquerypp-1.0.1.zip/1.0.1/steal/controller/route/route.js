steal('jquery/controller', 'can/control/route')
