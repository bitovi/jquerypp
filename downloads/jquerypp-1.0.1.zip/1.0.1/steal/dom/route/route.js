steal('jquery', 'can/util', 'can/route', function($, can) {
	$.route=can.route
})