steal("jquery", "can/util", "can/view", "can/view/modifiers",function($, can) {
	$.View = can.view;
	return $;
});
