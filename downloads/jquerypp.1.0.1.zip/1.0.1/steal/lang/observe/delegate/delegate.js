steal('jquery/lang/observe','can/observe/delegate',function(){


})
